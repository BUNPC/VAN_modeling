function [Amat,Bmat]=diffusion2(dt,sita,node,elem,ii,jj,connnum,vol,dcoeff,nng)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Build LHS matrix: diagonal/and off-diagonal parts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nn=length(node);
tic;fprintf(1,'building LHS matrix ...\n');
[Adiag,Aoffd,Bdiag,Boffd]=femadvdiffu(dt,sita,node,elem,vol,dcoeff,jj,connnum,cumsum(connnum));
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Create sparse form LHS matrix and the sub-blocks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Amat = sparse([ii,(1:nn)],[jj,(1:nn)],[Aoffd,Adiag],nn+nng,nn+nng); 
Bmat = sparse([ii,(1:nn)],[jj,(1:nn)],[Boffd,Bdiag],nn+nng,nn+nng);
