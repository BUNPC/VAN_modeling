function newc=diffusion2solve(dt,Amat,Bmat,oc,os,c,nodevol)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Build RHS: Bmat*c-OC+Oxygen Supply from Advection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rhs=Bmat*c+(-oc+os)*dt;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Solve for solutions at all freenodes: Amat*sol=rhs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%tic;fprintf(1,'solving for the solution ...\n');
%try
    newc=Amat\rhs;
% catch
%     debug=1;
% end

    %newc=bicgstab(Amat,rhs,1e-3,100);
%toc 
