/*
 * =============================================================
 * FEM Kernel for advection-diffusioin equation
 * Author: Qianqian Fang(fangq < at > nmr.mgh.harvard.edu)
 * Date: 2007/11/21
 * Version: 0.5.0
 *
 * Model:
 *    [A]*c=[B]*c-(OC+OS)*dt
 * where [A]=<phi_i,phi_j>+dt*sita*<D delPhi_i,delPhi_j>
 *       [B]=<phi_i,phi_j>-dt*(1-sita)*<D delPhi_i,delPhi_j>
 * OC is the vector for oxygen consumption at each node
 * boundary condition is dot(delc,normal)=0
 * =============================================================
 */

#include "mex.h"

double dt;   /*time step*/
double sita; /*implicity*/

void buildlhs(int nn,int ne, int ntot,double node[], double elem[],
              double volume[],double dcoeff[],double wrapidx[],double idxcount[],double idxsum[],
              double Adiag[],double Alhs[],double Bdiag[],double Blhs[]);
              
void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  double *node,*volume,*dcoeff;
  double *elem,*wrapidx,*idxcount,*idxsum;
  double *Adiag,*Alhs,*Bdiag,*Blhs; 
  int nn, ne, ntot;

  /* Get the matrices from the input list */
  dt=mxGetScalar(prhs[0]);
  sita=mxGetScalar(prhs[1]);
  node = mxGetPr(prhs[2]);
  elem = mxGetPr(prhs[3]);
  dcoeff = mxGetPr(prhs[4]);  
  volume = mxGetPr(prhs[5]);
  wrapidx = mxGetPr(prhs[6]);
  idxcount = mxGetPr(prhs[7]);
  idxsum = mxGetPr(prhs[8]);

  nn=mxGetM(prhs[2]);
  ne=mxGetM(prhs[3]);
  ntot=mxGetM(prhs[6])>mxGetN(prhs[6])?mxGetM(prhs[6]):mxGetN(prhs[6]);
  printf("node=%d\nelem=%d\ntotal=%d\n",nn,ne,ntot);
  
  /* Assign a pointer to the output. */
  plhs[0] = mxCreateDoubleMatrix(1,nn, mxREAL);
  plhs[1] = mxCreateDoubleMatrix(1,ntot, mxREAL);
  plhs[2] = mxCreateDoubleMatrix(1,nn, mxREAL);
  plhs[3] = mxCreateDoubleMatrix(1,ntot, mxREAL);
      
  Adiag= mxGetPr(plhs[0]);
  Alhs= mxGetPr(plhs[1]);
  Bdiag= mxGetPr(plhs[2]);
  Blhs= mxGetPr(plhs[3]);
    
  if(nn<=0||ne<=0||mxGetN(prhs[2])!=3||mxGetN(prhs[3])!=4)
      mexErrMsgTxt("dimensions of the input or output parameters are incorrect.");
  
  buildlhs(nn,ne,ntot,node,elem,dcoeff,volume,wrapidx,idxcount,idxsum,
          Adiag,Alhs,Bdiag,Blhs);
}


void buildlhs(int nn,int ne, int ntot,double node[], double elem[],
              double volume[],double dcoeff[],double wrapidx[],double idxcount[],double idxsum[],
              double Adiag[],double Alhs[],double Bdiag[],double Blhs[])
{
    double *x,*y,*z;
    double *e1,*e2,*e3,*e4;
    int i1,i2,i3,i4,i,j,k,t,ii,jj,ij,base;
    double derx[4],dery[4],derz[4];
    double ra,rb,Ve,Ve6,deldotdel,dtsita,adtsita,dsum,sm;
    
    /*initialize output variables*/
    memset(Adiag,0,nn*sizeof(double));
    memset(Alhs,0,ntot*sizeof(double));
    memset(Bdiag,0,nn*sizeof(double));
    memset(Blhs,0,ntot*sizeof(double));
    
    /* map coordinate pointers*/
    x=node;
    y=x+nn;
    z=y+nn;
    
    /* map element points*/
    e1=elem;
    e2=e1+ne;
    e3=e2+ne;
    e4=e3+ne;
    
    dtsita=dt*sita/4.0;
    adtsita=dt*(1.0-sita)/4.0;
    
    /* loop over all elements*/
    for(t=0;t<ne;t++)
    {
        Ve6=volume[t]*6.0;
        Ve =volume[t];
        
        i1=(int)(e1[t]-1);
        i2=(int)(e2[t]-1);
        i3=(int)(e3[t]-1);
        i4=(int)(e4[t]-1);

        /*calculate del_x,del_y and del_z for 4 basis functions per elem*/
        derx[0]=-((y[i3]*z[i4]-z[i3]*y[i4])-y[i2]*(z[i4]-z[i3])
               +z[i2]*(y[i4]-y[i3]))/Ve6;
        dery[0]=((x[i3]*z[i4]-x[i4]*z[i3])-x[i2]*(z[i4]-z[i3])
               +z[i2]*(x[i4]-x[i3]))/Ve6;
        derz[0]=-((x[i3]*y[i4]-y[i3]*x[i4])-x[i2]*(y[i4]-y[i3])
               +y[i2]*(x[i4]-x[i3]))/Ve6;

        derx[1]=((y[i3]*z[i4]-z[i3]*y[i4])-y[i1]*(z[i4]-z[i3])
               +z[i1]*(y[i4]-y[i3]))/Ve6;
        dery[1]=-((x[i3]*z[i4]-x[i4]*z[i3])-x[i1]*(z[i4]-z[i3])
               +z[i1]*(x[i4]-x[i3]))/Ve6;
        derz[1]=((x[i3]*y[i4]-y[i3]*x[i4])-x[i1]*(y[i4]-y[i3])
               +y[i1]*(x[i4]-x[i3]))/Ve6;

        derx[2]=-((y[i2]*z[i4]-z[i2]*y[i4])-y[i1]*(z[i4]-z[i2])
               +z[i1]*(y[i4]-y[i2]))/Ve6;
        dery[2]=((x[i2]*z[i4]-x[i4]*z[i2])-x[i1]*(z[i4]-z[i2])
               +z[i1]*(x[i4]-x[i2]))/Ve6;
        derz[2]=-((x[i2]*y[i4]-y[i2]*x[i4])-x[i1]*(y[i4]-y[i2])
               +y[i1]*(x[i4]-x[i2]))/Ve6;

        derx[3]=((y[i2]*z[i3]-z[i2]*y[i3])-y[i1]*(z[i3]-z[i2])
               +z[i1]*(y[i3]-y[i2]))/Ve6;
        dery[3]=-((x[i2]*z[i3]-x[i3]*z[i2])-x[i1]*(z[i3]-z[i2])
               +z[i1]*(x[i3]-x[i2]))/Ve6;
        derz[3]=((x[i2]*y[i3]-y[i2]*x[i3])-x[i1]*(y[i3]-y[i2])
               +y[i1]*(x[i3]-x[i2]))/Ve6;

        /*loop over index i*/
        for(i=0;i<4;i++)
        {
          ii = (int)(elem[t+i*ne]-1);
          /*loop over index j*/
          for(j=0;j<4;j++)
          {

            jj = (int)(elem[t+j*ne]-1);
            deldotdel=(derx[i]*derx[j]+dery[i]*dery[j]+derz[i]*derz[j])*Ve;
            
            sm = Ve/20.0;
            if (i==j) sm = Ve/10.0;

 /*
 * Model:
 *    [A]*c=[B]*c-(OC+OS)*dt
 * where [A]=<phi_i,phi_j>+dt*sita*<D delPhi_i,delPhi_j>
 *       [B]=<phi_i,phi_j>-dt*(1-sita)*<D delPhi_i,delPhi_j>
 */
             
            /*dt*sita*(D1+D2+D3+D4)/4*Ve*delFi*delFj = (dt*sita/4)*(D1+D2+D3+D4)*(Ve*delFi*delFj)  */
            dsum=dcoeff[i1]+dcoeff[i2]+dcoeff[i3]+dcoeff[i4];
            ra=dtsita*dsum*deldotdel+sm;
            rb=-adtsita*dsum*deldotdel+sm;
            
            /*add the values to the vectorized sparse matrix*/
            if(ii==jj)
            {
                Adiag[ii]+=ra;
                Bdiag[ii]+=rb;
            }
            else
            {
                base = (int)(idxsum[ii] - idxcount[ii]);
                for(k=0;k<(int)(idxcount[ii]);k++)
                {
                    ij = k + base;
                    if ((int)(wrapidx[ij])-1 == jj) break;
                }
                if((int)(wrapidx[ij])-1 != jj) 
                        mexErrMsgTxt("node connection information was wrong.");
                Alhs[ij]+=ra;
                Blhs[ij]+=rb;
            }
          }
        }
    }
}
