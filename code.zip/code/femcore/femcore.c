/*
 * =============================================================
 * FEM Kernel for general PDE systems (from an expression)
 *
 * Author: Qianqian Fang(fangq < at > nmr.mgh.harvard.edu)
 * Date: 2009/04/07
 * Version: 0.5
 *
 * Model:
 *    [A]*c=RHS
 * where [A]=c1*<delPhi_i,delPhi_j>+c2*<Phi_i,Phi_j>+c3*...
 *
 * {ci} are coefficients, Phi is the basis function, del is \del
 *
 * this subroutine does not set the boundary condition
 * =============================================================
 */

#include <string.h>
#include "mex.h"


enum FEM_Type {ft2DSurface=1,ftNoCoeff=2};

typedef struct FEMData{
	int nn;
	int ne;
	int ntot;
	double node[];
	double elem[];
	double volume[];
	double coeff[];
	double wrapidx[];
	double idxcount[];
	double idxsum[];
	double Adiag[];
	double Alhs[];
} FEMConfig;

void femcore_parse_equ(char *equ, FEMConfig *cfg);
void femcore3d_add_phidotphi(FEMConfig *cfg, FEM_Type type);
void femcore3d_add_deldotdel(FEMConfig *cfg, FEM_Type type);
void femcore_error(char *msg);

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
    FEMConfig cfg;
    double *node,*volume;
    mxArray *coeff;
    double *elem,*wrapidx,*idxcount,*idxsum;
    double *Adiag,*Alhs; 
    int nn, ne, ntot;
    int buflen,status;

    /* Get the matrices from the input list */
    cfg->node = mxGetPr(prhs[0]);
    cfg->elem = mxGetPr(prhs[1]);
    coeff = prhs[2];  /*all the coefficients, cell array*/
    cfg->volume = mxGetPr(prhs[3]);
    cfg->wrapidx = mxGetPr(prhs[4]);
    cfg->idxcount = mxGetPr(prhs[5]);
    cfg->idxsum = mxGetPr(prhs[6]);
    buflen = (mxGetM(prhs[7]) * mxGetN(prhs[7])) + 1;
    equ=mxCalloc(buflen,sizeof(char));
    status = mxGetString(prhs[7], equ, buflen);
    if (status != 0) 
      mexWarnMsgTxt("Not enough space. String is truncated.");

    equ= mxGetPr(prhs[7]);     /*equation, string array*/

    cfg->nn=mxGetM(prhs[0]);
    printf("node=%d\n",cfg->nn);
    cfg->ne=mxGetM(prhs[1]);
    printf("elem=%d\n",cfg->ne);
    cfg->ntot=mxGetM(prhs[4])>mxGetN(prhs[4])?mxGetM(prhs[4]):mxGetN(prhs[4]);
    printf("tot=%d\n",cfg->ntot);

    /* Assign a pointer to the output. */  
    plhs[0] = mxCreateDoubleMatrix(1,cfg->nn, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(1,cfg->ntot, mxREAL);

    cfg->Adiag= mxGetPr(plhs[0]);
    cfg->Alhs= mxGetPr(plhs[1]);

    /*initialize output variables*/
    memset(cfg->Adiag,0,nn*sizeof(double));
    memset(cfg->Alhs,0,ntot*sizeof(double));

    if(nn<=0||ne<=0||mxGetN(prhs[0])!=3||mxGetN(prhs[1])!=4)
	mexErrMsgTxt("dimensions of the input or output parameters are incorrect.");

    femcore_parse_equ(equ,cfg);
}

void femcore_error(char *msg){
	mexErrMsgTxt(msg);
}

void femcore_parse_equ(char *equ, FEMConfig *cfg){
	   
    char *pt=equ;
    int id;
    
    while(pt!=NULL){
    	if(*pt=='V'){
		sscanf(pt,"V%d",&id);
	}
	pt++;
    }
}

void femcore3d_add_phidotphi(FEMConfig *cfg, FEM_Type type){
    double *x,*y,*z;
    double *eidx[4];
    int i,j,k,t,ii,jj,ij,base;
    double ra,Ve,coeffsum,sm;
    
    /* map coordinate pointers*/
    x=cfg->node;y=x+cfg->nn;z=y+cfg->nn;
    
    /* map element points*/
    eidx[0]=cfg->elem;eidx[1]=cfg->elem+ne;eidx[2]=cfg->elem+2*ne;eidx[3]=cfg->elem+3*ne;
    
    /* loop over all elements*/
    for(t=0;t<cfg->ne;t++){
        Ve =cfg->volume[t];

        /*loop over index i*/
        for(i=0;i<4;i++){
          ii = (int)(eidx[i][t]-1);
          /*loop over index j*/
          for(j=0;j<4;j++){
            jj = (int)(eidx[j][t]-1);
            sm = Ve/20.0;
            if (i==j) sm = Ve/10.0;

            if(type&ftNoCoeff) {
	        coeffsum=(coeff[i1]+coeff[i2]+coeff[i3]+coeff[i4])/4.0;
	        ra=coeffsum*sm;
	    }else{
	        ra=sm;
	    }
            /*add the values to the vectorized sparse matrix*/
            if(ii==jj)
                cfg->Adiag[ii]+=ra;
            else {
                base = (int)(cfg->idxsum[ii] - cfg->idxcount[ii]);
		
                for(k=0;k<(int)(cfg->idxcount[ii]);k++){
                    ij = k + base;
                    if ((int)(cfg->wrapidx[ij])-1 == jj) break;
                }
                if((int)(cfg->wrapidx[ij])-1 != jj) 
                        mexErrMsgTxt("node connection information was wrong.");
                cfg->Alhs[ij]+=ra;
            }
          }
        }
    }
}

void femcore3d_add_deldotdel(FEMConfig *cfg, FEM_Type type){
    double *x,*y,*z;
    double *e1,*e2,*e3,*e4;
    int i1,i2,i3,i4,i,j,k,t,ii,jj,ij,base;
    double derx[4],dery[4],derz[4];
    double ra,rb,Ve,Ve6,deldotdel,coeffsum,sm;
    
    /* map coordinate pointers*/
    x=cfg->node;y=x+cfg->nn;z=y+cfg->nn;
    
    /* map element points*/
    e1=cfg->elem;e2=e1+cfg->ne;e3=e2+cfg->ne;e4=e3+cfg->ne;
    
    /* loop over all elements*/
    for(t=0;t<cfg->ne;t++){
        Ve6=cfg->volume[t]*6.0;
        Ve =cfg->volume[t];
        
        i1=(int)(e1[t]-1);
        i2=(int)(e2[t]-1);
        i3=(int)(e3[t]-1);
        i4=(int)(e4[t]-1);

	/*calculate del_x,del_y and del_z for 4 basis functions per elem*/
	derx[0]=-((y[i3]*z[i4]-z[i3]*y[i4])-y[i2]*(z[i4]-z[i3])
               +z[i2]*(y[i4]-y[i3]))/Ve6;
	dery[0]=((x[i3]*z[i4]-x[i4]*z[i3])-x[i2]*(z[i4]-z[i3])
               +z[i2]*(x[i4]-x[i3]))/Ve6;
	derz[0]=-((x[i3]*y[i4]-y[i3]*x[i4])-x[i2]*(y[i4]-y[i3])
               +y[i2]*(x[i4]-x[i3]))/Ve6;

	derx[1]=((y[i3]*z[i4]-z[i3]*y[i4])-y[i1]*(z[i4]-z[i3])
               +z[i1]*(y[i4]-y[i3]))/Ve6;
	dery[1]=-((x[i3]*z[i4]-x[i4]*z[i3])-x[i1]*(z[i4]-z[i3])
               +z[i1]*(x[i4]-x[i3]))/Ve6;
	derz[1]=((x[i3]*y[i4]-y[i3]*x[i4])-x[i1]*(y[i4]-y[i3])
               +y[i1]*(x[i4]-x[i3]))/Ve6;

	derx[2]=-((y[i2]*z[i4]-z[i2]*y[i4])-y[i1]*(z[i4]-z[i2])
               +z[i1]*(y[i4]-y[i2]))/Ve6;
	dery[2]=((x[i2]*z[i4]-x[i4]*z[i2])-x[i1]*(z[i4]-z[i2])
               +z[i1]*(x[i4]-x[i2]))/Ve6;
	derz[2]=-((x[i2]*y[i4]-y[i2]*x[i4])-x[i1]*(y[i4]-y[i2])
               +y[i1]*(x[i4]-x[i2]))/Ve6;

	derx[3]=((y[i2]*z[i3]-z[i2]*y[i3])-y[i1]*(z[i3]-z[i2])
               +z[i1]*(y[i3]-y[i2]))/Ve6;
	dery[3]=-((x[i2]*z[i3]-x[i3]*z[i2])-x[i1]*(z[i3]-z[i2])
               +z[i1]*(x[i3]-x[i2]))/Ve6;
	derz[3]=((x[i2]*y[i3]-y[i2]*x[i3])-x[i1]*(y[i3]-y[i2])
               +y[i1]*(x[i3]-x[i2]))/Ve6;

        /*loop over index i*/
        for(i=0;i<4;i++){
          ii = (int)(cfg->elem[t+i*ne]-1);
          /*loop over index j*/
          for(j=0;j<4;j++){
            jj = (int)(cfg->elem[t+j*ne]-1);

            deldotdel=derx[i]*derx[j]+dery[i]*dery[j]+derz[i]*derz[j])*Ve;

            sm = Ve/20.0;
            if (i==j) sm = Ve/10.0;
            
            /* (D1+D2+D3+D4)/4*Ve*delFi*delF */
            if(type&ftNoCoeff) {
                coeffsum=(coeff[i1]+coeff[i2]+coeff[i3]+coeff[i4])/4.0;
                ra=coeffsum*deldotdel;
	    }else{
	        ra=deldotdel;
	    }
	    
            /*add the values to the vectorized sparse matrix*/
            if(ii==jj)
                cfg->Adiag[ii]+=ra;
            else {
                base = (int)(cfg->idxsum[ii] - cfg->idxcount[ii]);
		
                for(k=0;k<(int)(cfg->idxcount[ii]);k++){
                    ij = k + base;

                    if ((int)(cfg->wrapidx[ij])-1 == jj) break;
                }
                if((int)(cfg->wrapidx[ij])-1 != jj) 
                        mexErrMsgTxt("node connection information was wrong.");
                cfg->Alhs[ij]+=ra;
            }
          }
        }
    }
}



