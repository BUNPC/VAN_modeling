nn=size(node,1);
c=zeros(nn,1);

dt=0.5;
tmax=100;
sita=0.5;

[ii,jj,connnum,barea,type2node,freenode]=prepmesh(node,elem,boundary);

oc=0.0*ones(nn,1);
os=zeros(nn,1);
nodearea=zeros(nn,1);

idx=find(boundary(:,end)==0);
for i=1:length(idx)
    nodearea(boundary(idx(i),1:3))=nodearea(boundary(idx(i),1:3))+barea(i);
end
nodearea=nodearea/3.0;

os(type2node)=0.2*nodearea(type2node);

dcoeff=10*ones(nn,1);

vol=elemvolume(elem,node);

[Amat,Bmat]=diffusion2(dt,sita,node,elem,ii,jj,connnum,vol,dcoeff);

%[xi,yi,zi]=meshgrid(50,1:100,1:100);
for i=1:tmax
	fprintf(1,'update iter=%d\n',i);
	c=diffusion2solve(dt,Amat,Bmat,oc,os,c);
	if(mod(i,5)==0) 
	        trisurf(boundary(:,1:3),node(:,1),node(:,2),node(:,3),c,'line','none');
		shading interp
		view(90,180)
		%vi=griddata3(node(:,1),node(:,2),node(:,3),c,xi,yi,zi);
		%pcolor(squeeze(vi));
		colorbar;
		waitforbuttonpress;
	end
end
