/*
 * =============================================================
 * FEM Kernel for diffusioin equation
 * Author: Qianqian Fang(fangq < at > nmr.mgh.harvard.edu)
 * Date: 2007/11/21
 * Version: 0.5.0
 *
 * Model:
 *    [A]*c=-OC
 * where [A]=<D delPhi_i,delPhi_j>
 * OC is the vector for oxygen consumption at each node
 * boundary condition is dot(delc,normal)=0
 * =============================================================
 */

#include "mex.h"

void femdiffu(int nn,int ne, int ntot,double node[], double elem[],
              double volume[],double dcoeff[],double wrapidx[],double idxcount[],double idxsum[],
              double Adiag[],double Alhs[]);
              
void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  double *node,*volume,*dcoeff;
  double *elem,*wrapidx,*idxcount,*idxsum;
  double *Adiag,*Alhs; 
  int nn, ne, ntot;

  /* Get the matrices from the input list */
  node = mxGetPr(prhs[0]);
  elem = mxGetPr(prhs[1]);
  dcoeff = mxGetPr(prhs[2]);  
  volume = mxGetPr(prhs[3]);
  wrapidx = mxGetPr(prhs[4]);
  idxcount = mxGetPr(prhs[5]);
  idxsum = mxGetPr(prhs[6]);

  nn=mxGetM(prhs[0]);
  printf("node=%d\n",nn);
  ne=mxGetM(prhs[1]);
  printf("elem=%d\n",ne);
  ntot=mxGetM(prhs[4])>mxGetN(prhs[4])?mxGetM(prhs[4]):mxGetN(prhs[4]);
  printf("tot=%d\n",ntot);
  
  /* Assign a pointer to the output. */  
  plhs[0] = mxCreateDoubleMatrix(1,nn, mxREAL);
  plhs[1] = mxCreateDoubleMatrix(1,ntot, mxREAL);

  Adiag= mxGetPr(plhs[0]);
  Alhs= mxGetPr(plhs[1]);
  
  if(nn<=0||ne<=0||mxGetN(prhs[0])!=3||mxGetN(prhs[1])!=4)
      mexErrMsgTxt("dimensions of the input or output parameters are incorrect.");
  
  femdiffu(nn,ne,ntot,node,elem,dcoeff,volume,wrapidx,idxcount,idxsum,
          Adiag,Alhs);
}


void femdiffu(int nn,int ne, int ntot,double node[], double elem[],
              double volume[],double dcoeff[],double wrapidx[],double idxcount[],double idxsum[],
              double Adiag[],double Alhs[])
{
    double *x,*y,*z;
    double *e1,*e2,*e3,*e4;
    int i1,i2,i3,i4,i,j,k,t,ii,jj,ij,base;
    double derx[4],dery[4],derz[4];
    double ra,rb,Ve,Ve6,deldotdel,dsum,sm;
    
    /*initialize output variables*/
    memset(Adiag,0,nn*sizeof(double));
    memset(Alhs,0,ntot*sizeof(double));
    
    /* map coordinate pointers*/
    x=node;
    y=x+nn;
    z=y+nn;
    
    /* map element points*/
    e1=elem;
    e2=e1+ne;
    e3=e2+ne;
    e4=e3+ne;

    
    /* loop over all elements*/
    for(t=0;t<ne;t++)
    {
        Ve6=volume[t]*6.0;
        Ve =volume[t];
        
        i1=(int)(e1[t]-1);
        i2=(int)(e2[t]-1);
        i3=(int)(e3[t]-1);
        i4=(int)(e4[t]-1);

        /*calculate del_x,del_y and del_z for 4 basis functions per elem*/
        derx[0]=-((y[i3]*z[i4]-z[i3]*y[i4])-y[i2]*(z[i4]-z[i3])
               +z[i2]*(y[i4]-y[i3]))/Ve6;
        dery[0]=((x[i3]*z[i4]-x[i4]*z[i3])-x[i2]*(z[i4]-z[i3])
               +z[i2]*(x[i4]-x[i3]))/Ve6;
        derz[0]=-((x[i3]*y[i4]-y[i3]*x[i4])-x[i2]*(y[i4]-y[i3])
               +y[i2]*(x[i4]-x[i3]))/Ve6;

        derx[1]=((y[i3]*z[i4]-z[i3]*y[i4])-y[i1]*(z[i4]-z[i3])
               +z[i1]*(y[i4]-y[i3]))/Ve6;
        dery[1]=-((x[i3]*z[i4]-x[i4]*z[i3])-x[i1]*(z[i4]-z[i3])
               +z[i1]*(x[i4]-x[i3]))/Ve6;
        derz[1]=((x[i3]*y[i4]-y[i3]*x[i4])-x[i1]*(y[i4]-y[i3])
               +y[i1]*(x[i4]-x[i3]))/Ve6;

        derx[2]=-((y[i2]*z[i4]-z[i2]*y[i4])-y[i1]*(z[i4]-z[i2])
               +z[i1]*(y[i4]-y[i2]))/Ve6;
        dery[2]=((x[i2]*z[i4]-x[i4]*z[i2])-x[i1]*(z[i4]-z[i2])
               +z[i1]*(x[i4]-x[i2]))/Ve6;
        derz[2]=-((x[i2]*y[i4]-y[i2]*x[i4])-x[i1]*(y[i4]-y[i2])
               +y[i1]*(x[i4]-x[i2]))/Ve6;

        derx[3]=((y[i2]*z[i3]-z[i2]*y[i3])-y[i1]*(z[i3]-z[i2])
               +z[i1]*(y[i3]-y[i2]))/Ve6;
        dery[3]=-((x[i2]*z[i3]-x[i3]*z[i2])-x[i1]*(z[i3]-z[i2])
               +z[i1]*(x[i3]-x[i2]))/Ve6;
        derz[3]=((x[i2]*y[i3]-y[i2]*x[i3])-x[i1]*(y[i3]-y[i2])
               +y[i1]*(x[i3]-x[i2]))/Ve6;

        /*loop over index i*/
        for(i=0;i<4;i++)
        {
          ii = (int)(elem[t+i*ne]-1);
          /*loop over index j*/
          for(j=0;j<4;j++)
          {
            jj = (int)(elem[t+j*ne]-1);
            deldotdel=(derx[i]*derx[j]+dery[i]*dery[j]+derz[i]*derz[j])*Ve;
            
            sm = Ve/20.0;
            if (i==j) sm = Ve/10.0;
            
            /* (D1+D2+D3+D4)/4*Ve*delFi*delF */
            dsum=(dcoeff[i1]+dcoeff[i2]+dcoeff[i3]+dcoeff[i4])/4.0;
            ra=dsum*deldotdel; /*+sm;*/
            
            /*add the values to the vectorized sparse matrix*/
            if(ii==jj){
		if(ii==1){
			printf("ra=%f dsum=%f deldotdel=%f\n %d %d %d %d %d %f\n",ra,dsum,deldotdel,i,j,k,ii,jj,sm);
                }
                Adiag[ii]+=ra;
            }
            else
            {
                base = (int)(idxsum[ii] - idxcount[ii]);
		
                for(k=0;k<(int)(idxcount[ii]);k++)
                {
                    ij = k + base;

                    if ((int)(wrapidx[ij])-1 == jj) break;
                }
                if((int)(wrapidx[ij])-1 != jj) 
                        mexErrMsgTxt("node connection information was wrong.");
                Alhs[ij]+=ra;
            }
          }
        }
    }
}
