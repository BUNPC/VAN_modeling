%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Test drive subroutine for FEM diffusion solver
%  fangq, 2007/12/17
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   input: node, elem, boundary
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% nn: number of nodes, ne: number of elements
nn=length(node);
ne=length(elem);

% dcoeff: diffusion coeff, oc: oxygen consumption, 
% bcond: boundary condition, only those with boundary=1 
%  are used, the rest will be overwritten by the solution

dcoeff=0.1*ones(nn,1);
oc=0.02*ones(nn,1);
bcond=10*ones(nn,1);

% idx&bb: all surf. elem with tag 0 (vessel surface)
% type1node: indices of Type-1 BC nodes (vessel surface)
% freenode:  indices of the remaining nodes

idx=find(boundary(:,end)==0);
bb=boundary(idx,1:3);
allnodes=zeros(nn,1);
allnodes(bb(:))=1;
type1node=find(allnodes==1); 
freenode=find(allnodes==0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Calculate element volume & the indices of non-zero
%   elements of LHS matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(1,'analyzing mesh connections ...\n');
tic;
vol=elemvolume(elem,node);
[ii,jj,connnum]=femnz(elem,nn);
ntot=sum(connnum);
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Build LHS matrix: diagonal/and off-diagonal entries
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic;fprintf(1,'building LHS matrix ...\n');
[Adiag,Aoffd]=femdiffu(node,elem,vol,dcoeff,jj,connnum,cumsum(connnum));
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Create sparse form LHS matrix and the sub-blocks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Amat = sparse([ii,(1:nn)],[jj,(1:nn)],[Aoffd,Adiag],nn,nn); 
Afree=Amat(freenode,freenode); 
Atrans=Amat(freenode,type1node);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Build RHS: -OC-A(ifree,ibc)*bc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rhs=-oc(freenode)-Atrans*bcond(type1node);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Solve for solutions at all freenodes: Afree*sol=rhs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic;fprintf(1,'solving for the solution ...\n');
sol=Afree\rhs;
toc 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Merge freenode solution with boundary conditions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

val=bcond;
val(freenode)=sol;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Visualization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf(1,'plot the results ...\n');

[xi,yi,zi]=meshgrid(1:5:100,1:5:100,1:5:100); 
vv=griddata3(node(:,1),node(:,2),node(:,3),val,xi,yi,zi);
idx=find(boundary(:,end)==0);
trisurf(boundary(:,1:3),node(:,1),node(:,2),node(:,3),val)
slice(xi,yi,zi,vv,[20 50],[],[50]) 
axis equal
colorbar


%mex femadvdiff.c 
%[AAdiag,AAlhs,BBdiag,BBlhs]=femadvdiff(0.1,0.5,node,elem,vol,0.1*ones(nn,1),jj,connnum,cumsum(connnum));
